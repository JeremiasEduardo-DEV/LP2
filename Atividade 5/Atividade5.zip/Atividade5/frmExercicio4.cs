﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_CalSalario_Click(object sender, EventArgs e)
        {
            string nome = txt_nome.Text;
            string matricula = txt_matricula.Text;

            if (int.TryParse(txt_producao.Text, out int producao) &&
                double.TryParse(txt_salario.Text, out double salarioA) && 
                double.TryParse(txt_gratificacao.Text, out double gratificacao))
            {
                int b = (producao >= 100) ? 1 : 0;
                int c = (producao >= 120) ? 1 : 0;
                int d = (producao >= 150) ? 1 : 0;

                double salarioBruto = salarioA + salarioA * (0.05 * b + 0.10 * c + 0.10 * d) + gratificacao;

                if (salarioBruto > 7000.00)
                {
                    bool temDireitoAcimaDe7000 = (producao >= 150 && gratificacao > 0);

                    if (!temDireitoAcimaDe7000)
                    {
                        salarioBruto = 7000.00;
                    }
                }

                string mensagem = $"Funcionário: {nome}\n" +
                                  $"Matricula: {matricula}\n\n" +
                                  $"Salário Bruto: R$ {salarioBruto.ToString("F2")}";

                MessageBox.Show(mensagem, "Resumo do Pagamento");
            }
            else
            {
                MessageBox.Show("Por favor, verifique se Produçãp, Salário e Gratificação foram preenchidos corretamente com números.");
            }
        }
    }
}
