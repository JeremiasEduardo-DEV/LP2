﻿namespace Atividade5
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnCalEspacoBran = new System.Windows.Forms.Button();
            this.btnCalNumLetra = new System.Windows.Forms.Button();
            this.btnCalNumParLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(53, 8);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rchtxtFrase.MaxLength = 100;
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(428, 206);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "\'";
            // 
            // btnCalEspacoBran
            // 
            this.btnCalEspacoBran.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnCalEspacoBran.Location = new System.Drawing.Point(27, 233);
            this.btnCalEspacoBran.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCalEspacoBran.Name = "btnCalEspacoBran";
            this.btnCalEspacoBran.Size = new System.Drawing.Size(127, 52);
            this.btnCalEspacoBran.TabIndex = 1;
            this.btnCalEspacoBran.Text = "Calcular número de espaços em branco";
            this.btnCalEspacoBran.UseVisualStyleBackColor = true;
            this.btnCalEspacoBran.Click += new System.EventHandler(this.btnCalEspacoBran_Click);
            // 
            // btnCalNumLetra
            // 
            this.btnCalNumLetra.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnCalNumLetra.Location = new System.Drawing.Point(205, 233);
            this.btnCalNumLetra.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCalNumLetra.Name = "btnCalNumLetra";
            this.btnCalNumLetra.Size = new System.Drawing.Size(127, 52);
            this.btnCalNumLetra.TabIndex = 2;
            this.btnCalNumLetra.Text = "Calcular número de vezes que apareceu a letra R";
            this.btnCalNumLetra.UseVisualStyleBackColor = true;
            this.btnCalNumLetra.Click += new System.EventHandler(this.btnCalNumLetra_Click);
            // 
            // btnCalNumParLetras
            // 
            this.btnCalNumParLetras.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            this.btnCalNumParLetras.Location = new System.Drawing.Point(382, 233);
            this.btnCalNumParLetras.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCalNumParLetras.Name = "btnCalNumParLetras";
            this.btnCalNumParLetras.Size = new System.Drawing.Size(127, 52);
            this.btnCalNumParLetras.TabIndex = 3;
            this.btnCalNumParLetras.Text = "Calcular número de veses que ocorre um mesmo par de letras na frase";
            this.btnCalNumParLetras.UseVisualStyleBackColor = true;
            this.btnCalNumParLetras.Click += new System.EventHandler(this.btnCalNumParLetras_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.btnCalNumParLetras);
            this.Controls.Add(this.btnCalNumLetra);
            this.Controls.Add(this.btnCalEspacoBran);
            this.Controls.Add(this.rchtxtFrase);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.Load += new System.EventHandler(this.frmExercicio1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnCalEspacoBran;
        private System.Windows.Forms.Button btnCalNumLetra;
        private System.Windows.Forms.Button btnCalNumParLetras;
    }
}