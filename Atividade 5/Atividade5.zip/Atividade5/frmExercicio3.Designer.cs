﻿namespace Atividade5
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl2 = new System.Windows.Forms.Label();
            this.txt_resultado = new System.Windows.Forms.TextBox();
            this.btn_CalPalavra = new System.Windows.Forms.Button();
            this.lbl = new System.Windows.Forms.Label();
            this.txt_palavra = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(243, 206);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(86, 20);
            this.lbl2.TabIndex = 9;
            this.lbl2.Text = "Resultado:";
            // 
            // txt_resultado
            // 
            this.txt_resultado.Enabled = false;
            this.txt_resultado.Location = new System.Drawing.Point(362, 208);
            this.txt_resultado.Name = "txt_resultado";
            this.txt_resultado.Size = new System.Drawing.Size(227, 20);
            this.txt_resultado.TabIndex = 8;
            // 
            // btn_CalPalavra
            // 
            this.btn_CalPalavra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CalPalavra.Location = new System.Drawing.Point(311, 271);
            this.btn_CalPalavra.Name = "btn_CalPalavra";
            this.btn_CalPalavra.Size = new System.Drawing.Size(191, 63);
            this.btn_CalPalavra.TabIndex = 7;
            this.btn_CalPalavra.Text = "Calcular se a palavra é palíndromo";
            this.btn_CalPalavra.UseVisualStyleBackColor = true;
            this.btn_CalPalavra.Click += new System.EventHandler(this.btn_CalPalavra_Click);
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl.Location = new System.Drawing.Point(63, 166);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(259, 20);
            this.lbl.TabIndex = 6;
            this.lbl.Text = "Escreva uma palavra com 50 letras:";
            this.lbl.Click += new System.EventHandler(this.lbl_Click);
            // 
            // txt_palavra
            // 
            this.txt_palavra.Location = new System.Drawing.Point(362, 166);
            this.txt_palavra.MaxLength = 50;
            this.txt_palavra.Name = "txt_palavra";
            this.txt_palavra.Size = new System.Drawing.Size(227, 20);
            this.txt_palavra.TabIndex = 5;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.txt_resultado);
            this.Controls.Add(this.btn_CalPalavra);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.txt_palavra);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.TextBox txt_resultado;
        private System.Windows.Forms.Button btn_CalPalavra;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.TextBox txt_palavra;
    }
}