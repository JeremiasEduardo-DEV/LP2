﻿namespace Atividade5
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.txt_nome = new System.Windows.Forms.TextBox();
            this.txt_matricula = new System.Windows.Forms.TextBox();
            this.txt_producao = new System.Windows.Forms.TextBox();
            this.txt_salario = new System.Windows.Forms.TextBox();
            this.txt_gratificacao = new System.Windows.Forms.TextBox();
            this.btn_CalSalario = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(213, 39);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(67, 24);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Nome:";
            this.lbl1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(213, 90);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(90, 24);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "Matricula:";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(213, 144);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(97, 24);
            this.lbl3.TabIndex = 2;
            this.lbl3.Text = "Produção:";
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4.Location = new System.Drawing.Point(213, 196);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(72, 24);
            this.lbl4.TabIndex = 3;
            this.lbl4.Text = "Salário:";
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5.Location = new System.Drawing.Point(213, 253);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(112, 24);
            this.lbl5.TabIndex = 4;
            this.lbl5.Text = "Gratificação:";
            // 
            // txt_nome
            // 
            this.txt_nome.Location = new System.Drawing.Point(345, 44);
            this.txt_nome.Name = "txt_nome";
            this.txt_nome.Size = new System.Drawing.Size(220, 20);
            this.txt_nome.TabIndex = 5;
            // 
            // txt_matricula
            // 
            this.txt_matricula.Location = new System.Drawing.Point(345, 90);
            this.txt_matricula.Name = "txt_matricula";
            this.txt_matricula.Size = new System.Drawing.Size(220, 20);
            this.txt_matricula.TabIndex = 6;
            // 
            // txt_producao
            // 
            this.txt_producao.Location = new System.Drawing.Point(345, 144);
            this.txt_producao.Name = "txt_producao";
            this.txt_producao.Size = new System.Drawing.Size(220, 20);
            this.txt_producao.TabIndex = 7;
            // 
            // txt_salario
            // 
            this.txt_salario.Location = new System.Drawing.Point(345, 196);
            this.txt_salario.Name = "txt_salario";
            this.txt_salario.Size = new System.Drawing.Size(220, 20);
            this.txt_salario.TabIndex = 8;
            // 
            // txt_gratificacao
            // 
            this.txt_gratificacao.Location = new System.Drawing.Point(345, 253);
            this.txt_gratificacao.Name = "txt_gratificacao";
            this.txt_gratificacao.Size = new System.Drawing.Size(220, 20);
            this.txt_gratificacao.TabIndex = 9;
            // 
            // btn_CalSalario
            // 
            this.btn_CalSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CalSalario.Location = new System.Drawing.Point(300, 345);
            this.btn_CalSalario.Name = "btn_CalSalario";
            this.btn_CalSalario.Size = new System.Drawing.Size(191, 63);
            this.btn_CalSalario.TabIndex = 10;
            this.btn_CalSalario.Text = "Calcular salário bruto";
            this.btn_CalSalario.UseVisualStyleBackColor = true;
            this.btn_CalSalario.Click += new System.EventHandler(this.btn_CalSalario_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_CalSalario);
            this.Controls.Add(this.txt_gratificacao);
            this.Controls.Add(this.txt_salario);
            this.Controls.Add(this.txt_producao);
            this.Controls.Add(this.txt_matricula);
            this.Controls.Add(this.txt_nome);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.TextBox txt_nome;
        private System.Windows.Forms.TextBox txt_matricula;
        private System.Windows.Forms.TextBox txt_producao;
        private System.Windows.Forms.TextBox txt_salario;
        private System.Windows.Forms.TextBox txt_gratificacao;
        private System.Windows.Forms.Button btn_CalSalario;
    }
}