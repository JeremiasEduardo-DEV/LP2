﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_numH_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txt_num.Text, out int n))
            {
                if (n > 0)
                {
                    double h = 0;

                    for (int i = 1; i <= n; i++)
                    {
                        h += 1.0 / i;
                    }

                    txt_resultado.Text = h.ToString("F2");
                }
                else
                {
                    MessageBox.Show("O número deve ser maior que 0!");
                    txt_resultado.Clear();
                }
            }
            else
            {
                MessageBox.Show("Por favor, digite um número inteiro válido.");
                txt_resultado.Clear();
            }
        }
    }
}
