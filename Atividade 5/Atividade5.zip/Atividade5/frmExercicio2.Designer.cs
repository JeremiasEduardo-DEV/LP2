﻿namespace Atividade5
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_num = new System.Windows.Forms.TextBox();
            this.lbl = new System.Windows.Forms.Label();
            this.btn_numH = new System.Windows.Forms.Button();
            this.txt_resultado = new System.Windows.Forms.TextBox();
            this.lbl2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_num
            // 
            this.txt_num.Location = new System.Drawing.Point(326, 213);
            this.txt_num.Name = "txt_num";
            this.txt_num.Size = new System.Drawing.Size(166, 20);
            this.txt_num.TabIndex = 0;
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl.Location = new System.Drawing.Point(164, 211);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(156, 20);
            this.lbl.TabIndex = 1;
            this.lbl.Text = "Forneça um número:";
            this.lbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_numH
            // 
            this.btn_numH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_numH.Location = new System.Drawing.Point(301, 318);
            this.btn_numH.Name = "btn_numH";
            this.btn_numH.Size = new System.Drawing.Size(191, 63);
            this.btn_numH.TabIndex = 2;
            this.btn_numH.Text = "Calcular número H";
            this.btn_numH.UseVisualStyleBackColor = true;
            this.btn_numH.Click += new System.EventHandler(this.btn_numH_Click);
            // 
            // txt_resultado
            // 
            this.txt_resultado.Enabled = false;
            this.txt_resultado.Location = new System.Drawing.Point(326, 255);
            this.txt_resultado.Name = "txt_resultado";
            this.txt_resultado.Size = new System.Drawing.Size(166, 20);
            this.txt_resultado.TabIndex = 3;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(207, 253);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(86, 20);
            this.lbl2.TabIndex = 4;
            this.lbl2.Text = "Resultado:";
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.txt_resultado);
            this.Controls.Add(this.btn_numH);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.txt_num);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_num;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Button btn_numH;
        private System.Windows.Forms.TextBox txt_resultado;
        private System.Windows.Forms.Label lbl2;
    }
}