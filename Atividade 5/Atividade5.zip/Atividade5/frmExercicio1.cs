﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void frmExercicio1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalEspacoBran_Click(object sender, EventArgs e)
        {
            int contEspaços = 0;
            
            foreach (char letra in rchtxtFrase.Text)
            {
                if(letra == ' ')
                {
                    contEspaços++;
                }
            }

            MessageBox.Show($"Número de espaços em brancos: {contEspaços}");
        }

        private void btnCalNumLetra_Click(object sender, EventArgs e)
        {
            int contR = 0;
            int i = 0;

            string texto = rchtxtFrase.Text.ToUpper();

            while (i < texto.Length)
            {
                if (texto[i] == 'R')
                {
                    contR++;
                }
                i++;
            }

            MessageBox.Show($"A letra 'R' apareceu {contR} vezes.");
        }

        private void btnCalNumParLetras_Click(object sender, EventArgs e)
        {
            int contPares = 0;

            string texto = rchtxtFrase.Text.ToLower();

            for (int i = 0; i < texto.Length - 1; i++)
            {
                if(char.IsLetter(texto[i]) && texto[i] == texto[i + 1])
                {
                    contPares++;
                }
            }

            MessageBox.Show($"Número de pares de letras encontradas: {contPares}.");
        }
    }
}
