﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void lbl_Click(object sender, EventArgs e)
        {

        }

        private void btn_CalPalavra_Click(object sender, EventArgs e)
        {
            string textoFormatado = txt_palavra.Text.Replace(" ", "").ToUpper();

            if (string.IsNullOrEmpty(textoFormatado))
            {
                MessageBox.Show("Por favor, digite uma palavra ou frase.");
                return;
            }

            char[] arrayLetras = textoFormatado.ToCharArray();
            Array.Reverse(arrayLetras);

            string textoInvertido = new string(arrayLetras);

            if (textoFormatado == textoInvertido)
            {
                txt_resultado.Text = $"A palavra {textoFormatado} é palíndromo!";
            }
            else
            {
                txt_resultado.Text = $"A palavra {textoFormatado} não é palíndromo!";
            }
        }
    }
}
