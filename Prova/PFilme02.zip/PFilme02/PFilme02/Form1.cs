﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Executar_Click(object sender, EventArgs e)
        {
            string aux = "";
            


            double numero;
            double[,] Notas = new double [2, 2];

            double Media1 = 0;
            double Media2 = 0;

            int i = 0;
            int j = 0;

            for (i = 0; i < 2; i++)
            {
                

                double TotalNotas1 = 0;
                double TotalNotas2 = 0;

                

                for (j = 0; j < 2; j++)
                {
                    aux = Interaction.InputBox($"Digite a nota do filme{j + 1} da pessoa {i + 1}:", "Entrada de notas:");

                    bool sucesso = double.TryParse(aux, out numero);
                    if(!Double.TryParse(aux, out Notas[i, j]) || Notas[i, j] < 0 || Notas[i, j] > 10)
                    {
                        j--;
                        MessageBox.Show("Número inválido!");
                    }
                    else
                    {
                        if (i == 0)
                        {
                            TotalNotas1 += Notas[i, j];
                        }
                        else if (i == 1)
                        {
                            TotalNotas2 += Notas[i, j];
                        }
                    }
                    
                    
                    
                }
                Media1 = TotalNotas1 / 2;
                Media2 = TotalNotas2 / 2;

                
            }
            lbx_NotasFilmes.Items.Add($"Pessoa:{i + 1} Nota Filme 1: {Notas[0, 0].ToString("F2")} Nota Filme 2: {Notas[0, 1].ToString("F2")}");
            lbx_NotasFilmes.Items.Add($"Pessoa:{i + 1} Nota Filme 1: {Notas[1, 0].ToString("F2")} Nota Filme 2: {Notas[1, 1].ToString("F2")}");

            lbx_NotasFilmes.Items.Add("--------------------------------------------------");

            lbx_NotasFilmes.Items.Add($"Média Filme 1: {Media1}");
            lbx_NotasFilmes.Items.Add($"Média Filme 2: {Media2}");

        }
    }
}
