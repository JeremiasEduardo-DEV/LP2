﻿namespace PFilme02
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Executar = new System.Windows.Forms.Button();
            this.btn_Limpar = new System.Windows.Forms.Button();
            this.lbx_NotasFilmes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_Executar
            // 
            this.btn_Executar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_Executar.Location = new System.Drawing.Point(149, 54);
            this.btn_Executar.Name = "btn_Executar";
            this.btn_Executar.Size = new System.Drawing.Size(238, 192);
            this.btn_Executar.TabIndex = 0;
            this.btn_Executar.Text = "Executar";
            this.btn_Executar.UseVisualStyleBackColor = true;
            this.btn_Executar.Click += new System.EventHandler(this.btn_Executar_Click);
            // 
            // btn_Limpar
            // 
            this.btn_Limpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_Limpar.Location = new System.Drawing.Point(149, 351);
            this.btn_Limpar.Name = "btn_Limpar";
            this.btn_Limpar.Size = new System.Drawing.Size(238, 192);
            this.btn_Limpar.TabIndex = 1;
            this.btn_Limpar.Text = "Limpar";
            this.btn_Limpar.UseVisualStyleBackColor = true;
            // 
            // lbx_NotasFilmes
            // 
            this.lbx_NotasFilmes.FormattingEnabled = true;
            this.lbx_NotasFilmes.ItemHeight = 20;
            this.lbx_NotasFilmes.Location = new System.Drawing.Point(464, 54);
            this.lbx_NotasFilmes.Name = "lbx_NotasFilmes";
            this.lbx_NotasFilmes.Size = new System.Drawing.Size(579, 484);
            this.lbx_NotasFilmes.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1076, 593);
            this.Controls.Add(this.lbx_NotasFilmes);
            this.Controls.Add(this.btn_Limpar);
            this.Controls.Add(this.btn_Executar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Executar;
        private System.Windows.Forms.Button btn_Limpar;
        private System.Windows.Forms.ListBox lbx_NotasFilmes;
    }
}

