﻿namespace Patividade6
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Executar = new System.Windows.Forms.Button();
            this.lbx_nomes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_Executar
            // 
            this.btn_Executar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.btn_Executar.Location = new System.Drawing.Point(152, 177);
            this.btn_Executar.Name = "btn_Executar";
            this.btn_Executar.Size = new System.Drawing.Size(241, 105);
            this.btn_Executar.TabIndex = 0;
            this.btn_Executar.Text = "Executar";
            this.btn_Executar.UseVisualStyleBackColor = true;
            this.btn_Executar.Click += new System.EventHandler(this.btn_Executar_Click);
            // 
            // lbx_nomes
            // 
            this.lbx_nomes.FormattingEnabled = true;
            this.lbx_nomes.Location = new System.Drawing.Point(455, 65);
            this.lbx_nomes.Name = "lbx_nomes";
            this.lbx_nomes.Size = new System.Drawing.Size(324, 368);
            this.lbx_nomes.TabIndex = 1;
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbx_nomes);
            this.Controls.Add(this.btn_Executar);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.TopMost = true;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Executar;
        private System.Windows.Forms.ListBox lbx_nomes;
    }
}