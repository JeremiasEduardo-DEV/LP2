﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;
using System.Net.Http.Headers;

namespace Patividade6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Exercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string aux;

            for(int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o {i + 1} n°", "Entrada de Dados");
                if (!int.TryParse(aux,out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }
            Array.Reverse(vetor);

            aux = "";

            foreach(int i in vetor)
            {
                aux += i + "\n";
            }
            MessageBox.Show(aux);
        }

        private void btn_Exercicio2_Click(object sender, EventArgs e)
        {

            ArrayList alunos = new ArrayList()
            {
                "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais"
            };

            for (int i = alunos.Count - 1; i >= 0; i--){
                if (alunos[i].ToString() == "Otávio")
                {
                    alunos.Remove("Otávio");
                }
            }
            foreach (string aluno in alunos)
            {
                MessageBox.Show(aluno);
            }
            
        }

        private void btn_Exercicio3_Click(object sender, EventArgs e)
        {
            string aux = "";

            string saida = "";

            int numero;

            double[,] notas = new double[20, 3];

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                double Media = 0;
                double resultado = 0;
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    
                    aux = Interaction.InputBox($"aluno{i + 1} nota {j + 1}", "Entrada de Dados");

                    bool sucesso = int.TryParse(aux, out numero);                        
                    if (!Double.TryParse(aux,out notas[i,j]) || notas[i,j] < 0 || notas[i,j] > 10)
                    {
                        j--;
                        MessageBox.Show("Número inválido!");
                    }
                    else
                    {
                        Media += notas[i, j];
                    }
                }
                resultado = Media / 3;
                saida += $"Aluno {i + 1}: média: {resultado}\n";
            }
            MessageBox.Show(saida);
            
        }

        private void btn_Exercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 FrmExercicio4 = new frmExercicio4();
  
                FrmExercicio4.Show();
            }
        }

        private void btn_Exercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 FrmExercicio5 = new frmExercicio5();
       
                FrmExercicio5.Show();
            }
        }
    }
}
