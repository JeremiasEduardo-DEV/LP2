﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Patividade6
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btn_Verificar_Click(object sender, EventArgs e)
        {
            int N = 3;

            char[] vetGabarito = { 'A', 'B', 'C', 'D', 'A', 'B', 'C', 'D', 'A', 'B' };
            char[,] matRespostas = new char[N, 10];

            lbx_alunos.Items.Clear();

            for (int aluno = 0; aluno < N; aluno++)
            {
                for (int questao = 0; questao < 10; questao++)
                {
                    char respostaFinal = ' ';
                    bool respostaValida = false;

                    while (!respostaValida)
                    {
                        string entrada = Interaction.InputBox(
                            $"Aluno {aluno + 1} - Digite a resposta da questão {questao + 1}:",
                            "Entrada de Respostas",
                            ""
                        ).ToUpper();

                        if (entrada == "A" || entrada == "B" || entrada == "C" || entrada == "D" || entrada == "E")
                        {
                            respostaFinal = entrada[0];
                            respostaValida = true;
                        }
                        else
                        {
                            MessageBox.Show("Resposta inválida! Digite apenas A, B, C, D ou E.", "Erro");
                        }
                    }

                    matRespostas[aluno, questao] = respostaFinal;

                    string status = (matRespostas[aluno, questao] == vetGabarito[questao]) ? "acertou" : "errou";

                    string linhaResultado = $"O aluno:{aluno + 1} {status} questão:{questao + 1} era {vetGabarito[questao]} escolheu {matRespostas[aluno, questao]}";
                    lbx_alunos.Items.Add(linhaResultado);
                }
            }
        }
    }
}
