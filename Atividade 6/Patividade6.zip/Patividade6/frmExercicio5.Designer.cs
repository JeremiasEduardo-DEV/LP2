﻿namespace Patividade6
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Verificar = new System.Windows.Forms.Button();
            this.lbx_alunos = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_Verificar
            // 
            this.btn_Verificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.btn_Verificar.Location = new System.Drawing.Point(157, 167);
            this.btn_Verificar.Name = "btn_Verificar";
            this.btn_Verificar.Size = new System.Drawing.Size(241, 105);
            this.btn_Verificar.TabIndex = 1;
            this.btn_Verificar.Text = "Verificar";
            this.btn_Verificar.UseVisualStyleBackColor = true;
            this.btn_Verificar.Click += new System.EventHandler(this.btn_Verificar_Click);
            // 
            // lbx_alunos
            // 
            this.lbx_alunos.FormattingEnabled = true;
            this.lbx_alunos.Location = new System.Drawing.Point(435, 54);
            this.lbx_alunos.Name = "lbx_alunos";
            this.lbx_alunos.Size = new System.Drawing.Size(324, 368);
            this.lbx_alunos.TabIndex = 2;
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbx_alunos);
            this.Controls.Add(this.btn_Verificar);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.TopMost = true;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Verificar;
        private System.Windows.Forms.ListBox lbx_alunos;
    }
}