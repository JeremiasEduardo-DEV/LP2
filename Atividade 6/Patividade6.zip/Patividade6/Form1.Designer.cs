﻿namespace Patividade6
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Exercicio1 = new System.Windows.Forms.Button();
            this.btn_Exercicio2 = new System.Windows.Forms.Button();
            this.btn_Exercicio3 = new System.Windows.Forms.Button();
            this.btn_Exercicio4 = new System.Windows.Forms.Button();
            this.btn_Exercicio5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Exercicio1
            // 
            this.btn_Exercicio1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exercicio1.Location = new System.Drawing.Point(129, 85);
            this.btn_Exercicio1.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Exercicio1.Name = "btn_Exercicio1";
            this.btn_Exercicio1.Size = new System.Drawing.Size(127, 60);
            this.btn_Exercicio1.TabIndex = 0;
            this.btn_Exercicio1.Text = "Exercício 1";
            this.btn_Exercicio1.UseVisualStyleBackColor = true;
            this.btn_Exercicio1.Click += new System.EventHandler(this.btn_Exercicio1_Click);
            // 
            // btn_Exercicio2
            // 
            this.btn_Exercicio2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exercicio2.Location = new System.Drawing.Point(348, 85);
            this.btn_Exercicio2.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Exercicio2.Name = "btn_Exercicio2";
            this.btn_Exercicio2.Size = new System.Drawing.Size(127, 60);
            this.btn_Exercicio2.TabIndex = 1;
            this.btn_Exercicio2.Text = "Exercício 2";
            this.btn_Exercicio2.UseVisualStyleBackColor = true;
            this.btn_Exercicio2.Click += new System.EventHandler(this.btn_Exercicio2_Click);
            // 
            // btn_Exercicio3
            // 
            this.btn_Exercicio3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exercicio3.Location = new System.Drawing.Point(129, 192);
            this.btn_Exercicio3.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Exercicio3.Name = "btn_Exercicio3";
            this.btn_Exercicio3.Size = new System.Drawing.Size(127, 60);
            this.btn_Exercicio3.TabIndex = 2;
            this.btn_Exercicio3.Text = "Exercício 3";
            this.btn_Exercicio3.UseVisualStyleBackColor = true;
            this.btn_Exercicio3.Click += new System.EventHandler(this.btn_Exercicio3_Click);
            // 
            // btn_Exercicio4
            // 
            this.btn_Exercicio4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exercicio4.Location = new System.Drawing.Point(348, 192);
            this.btn_Exercicio4.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Exercicio4.Name = "btn_Exercicio4";
            this.btn_Exercicio4.Size = new System.Drawing.Size(127, 60);
            this.btn_Exercicio4.TabIndex = 3;
            this.btn_Exercicio4.Text = "Exercício 4";
            this.btn_Exercicio4.UseVisualStyleBackColor = true;
            this.btn_Exercicio4.Click += new System.EventHandler(this.btn_Exercicio4_Click);
            // 
            // btn_Exercicio5
            // 
            this.btn_Exercicio5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exercicio5.Location = new System.Drawing.Point(237, 302);
            this.btn_Exercicio5.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Exercicio5.Name = "btn_Exercicio5";
            this.btn_Exercicio5.Size = new System.Drawing.Size(127, 60);
            this.btn_Exercicio5.TabIndex = 4;
            this.btn_Exercicio5.Text = "Exercício 5";
            this.btn_Exercicio5.UseVisualStyleBackColor = true;
            this.btn_Exercicio5.Click += new System.EventHandler(this.btn_Exercicio5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 393);
            this.Controls.Add(this.btn_Exercicio5);
            this.Controls.Add(this.btn_Exercicio4);
            this.Controls.Add(this.btn_Exercicio3);
            this.Controls.Add(this.btn_Exercicio2);
            this.Controls.Add(this.btn_Exercicio1);
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Exercicio1;
        private System.Windows.Forms.Button btn_Exercicio2;
        private System.Windows.Forms.Button btn_Exercicio3;
        private System.Windows.Forms.Button btn_Exercicio4;
        private System.Windows.Forms.Button btn_Exercicio5;
    }
}

