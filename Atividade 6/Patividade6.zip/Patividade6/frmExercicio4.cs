﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade6
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btn_Executar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] tamanhos = new int[10];

            lbx_nomes.Items.Clear();

            for (int i = 0; i < 10; i++)
            {
                string nomeDigitado = "";

                while (string.IsNullOrWhiteSpace(nomeDigitado))
                {
                    nomeDigitado = Interaction.InputBox($"Digite o nome da pessoa {i + 1} de 10:", "Entrada de Dados", "");

                    if (string.IsNullOrWhiteSpace(nomeDigitado))
                    {
                        MessageBox.Show("O nome não pode ficar vazio ou ter apenas espaços em branco!", "Atenção");
                    }
                }

                nomes[i] = nomeDigitado;

                string nomeSemEspacos = nomeDigitado.Replace(" ", "");
                tamanhos[i] = nomeSemEspacos.Length;
            }

            for (int i = 0; i < 10; i++)
            {
                lbx_nomes.Items.Add($"o nome:{nomes[i]} tem {tamanhos[i]} caracteres");
            }
        }
    }
}
