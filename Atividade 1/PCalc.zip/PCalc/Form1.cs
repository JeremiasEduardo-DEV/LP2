﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Calculadora : Form
    {
        double Numero1;
        double Numero2;
        double Resultado;

        bool limpando = false;
        public Calculadora()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if(this.ActiveControl == btnSair)
            {
                return;
            }
            if (this.ActiveControl == btnLimpar)
            {
                return;
            }
            if (this.ActiveControl == btnLimpar)
            {
                limpando = true;
                return;
            }
            else
            {
                limpando = false;
            }
            if (!double.TryParse(txtNumero1.Text, out Numero1))
            {
                MessageBox.Show("Número inválido");
                txtNumero1.Focus();
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if(this.ActiveControl == btnSair)
            {
                return;
            }
            
            if (this.ActiveControl == btnLimpar)
            {
                limpando = true;
                return;
            }
            else
            {
                limpando = false;
            }
            if (!double.TryParse(txtNumero2.Text, out Numero2) && limpando == false)
            {
                MessageBox.Show("Número inválido");
                txtNumero2.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            this.txtNumero1.Clear();
            this.txtNumero2.Clear();
            this.txtResultado.Clear();

            Numero1 = 0;
            Numero2 = 0;
            Resultado = 0;

            txtNumero1.Focus();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;

            txtResultado.Text = Resultado.ToString();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;

            txtResultado.Text = Resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;

            txtResultado.Text = Resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if(Numero1 == 0 || Numero2 == 0)
            {
                MessageBox.Show("Não é possivel realizar divisão por 0");
                txtNumero1.Focus();
            }
            else
            {
                Resultado = Numero1 / Numero2;

                txtResultado.Text = Resultado.ToString();
            }
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            return;
        }
    }
}
