﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double Peso;
        double Altura;
        double Resultado;

        bool limpando;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (this.ActiveControl == btnLimpar)
            {
                return;
            }
            if (this.ActiveControl == btnLimpar)
            {
                limpando = true;
                return;
            }
            else
            {
                limpando = false;
            }
            if (!double.TryParse(mskbxPeso.Text, out Peso) || Peso < 0)
            {
                MessageBox.Show("Peso inválido");
                mskbxPeso.Focus();
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }
            if (this.ActiveControl == btnLimpar)
            {
                return;
            }
            if (this.ActiveControl == btnLimpar)
            {
                limpando = true;
                return;
            }
            else
            {
                limpando = false;
            }
            if (!double.TryParse(mskbxAltura.Text, out Altura) || Altura < 0)
            {
                MessageBox.Show("Altura inválido");
                mskbxAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Resultado = Peso / (Math.Pow(Altura, 2));
            Resultado = Math.Round(Resultado,1);
            txtIMC.Text = Resultado.ToString();

            if(Resultado < 18.5)
            {
                MessageBox.Show("Magreza");;
            }
            else if (Resultado < 24.9)
            {
                MessageBox.Show("Normal"); ;
            }
            else if (Resultado < 29.9)
            {
                MessageBox.Show("Sobrepeso");
            }
            else if (Resultado < 39.9)
            {
                MessageBox.Show("Obesidade"); ;
            }
            else if (Resultado < 40)
            {
                MessageBox.Show("Obesidade Grave"); ;
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            this.mskbxPeso.Clear();
            this.mskbxAltura.Clear();
            this.txtIMC.Clear();

            Peso = 0;
            Altura = 0;
            Resultado = 0;

            mskbxPeso.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            return;
        }
    }
}
