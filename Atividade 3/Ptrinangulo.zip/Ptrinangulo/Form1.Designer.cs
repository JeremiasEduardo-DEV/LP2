﻿namespace Ptrinangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl_A = new System.Windows.Forms.Label();
            this.lbl_B = new System.Windows.Forms.Label();
            this.lbl_C = new System.Windows.Forms.Label();
            this.btn_calcular = new System.Windows.Forms.Button();
            this.btn_limpar = new System.Windows.Forms.Button();
            this.btn_sair = new System.Windows.Forms.Button();
            this.lbl_resultado = new System.Windows.Forms.Label();
            this.txt_A = new System.Windows.Forms.TextBox();
            this.txt_B = new System.Windows.Forms.TextBox();
            this.txt_C = new System.Windows.Forms.TextBox();
            this.txt_resultado = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.txt_Triangulo = new System.Windows.Forms.TextBox();
            this.lbl_Triangulo = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_A
            // 
            this.lbl_A.AutoSize = true;
            this.lbl_A.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lbl_A.Location = new System.Drawing.Point(18, 20);
            this.lbl_A.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_A.Name = "lbl_A";
            this.lbl_A.Size = new System.Drawing.Size(120, 26);
            this.lbl_A.TabIndex = 0;
            this.lbl_A.Text = "Valor de A:";
            // 
            // lbl_B
            // 
            this.lbl_B.AutoSize = true;
            this.lbl_B.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lbl_B.Location = new System.Drawing.Point(18, 70);
            this.lbl_B.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_B.Name = "lbl_B";
            this.lbl_B.Size = new System.Drawing.Size(120, 26);
            this.lbl_B.TabIndex = 1;
            this.lbl_B.Text = "Valor de B:";
            this.lbl_B.Click += new System.EventHandler(this.label2_Click);
            // 
            // lbl_C
            // 
            this.lbl_C.AutoSize = true;
            this.lbl_C.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lbl_C.Location = new System.Drawing.Point(17, 124);
            this.lbl_C.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_C.Name = "lbl_C";
            this.lbl_C.Size = new System.Drawing.Size(121, 26);
            this.lbl_C.TabIndex = 2;
            this.lbl_C.Text = "Valor de C:";
            // 
            // btn_calcular
            // 
            this.btn_calcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calcular.Location = new System.Drawing.Point(22, 238);
            this.btn_calcular.Margin = new System.Windows.Forms.Padding(2);
            this.btn_calcular.Name = "btn_calcular";
            this.btn_calcular.Size = new System.Drawing.Size(127, 47);
            this.btn_calcular.TabIndex = 4;
            this.btn_calcular.Text = "Calcular";
            this.btn_calcular.UseVisualStyleBackColor = true;
            this.btn_calcular.Click += new System.EventHandler(this.btn_calcular_Click);
            // 
            // btn_limpar
            // 
            this.btn_limpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_limpar.Location = new System.Drawing.Point(243, 238);
            this.btn_limpar.Margin = new System.Windows.Forms.Padding(2);
            this.btn_limpar.Name = "btn_limpar";
            this.btn_limpar.Size = new System.Drawing.Size(127, 47);
            this.btn_limpar.TabIndex = 5;
            this.btn_limpar.Text = "Limpar";
            this.btn_limpar.UseVisualStyleBackColor = true;
            this.btn_limpar.Click += new System.EventHandler(this.btn_limpar_Click);
            // 
            // btn_sair
            // 
            this.btn_sair.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sair.Location = new System.Drawing.Point(463, 238);
            this.btn_sair.Margin = new System.Windows.Forms.Padding(2);
            this.btn_sair.Name = "btn_sair";
            this.btn_sair.Size = new System.Drawing.Size(127, 47);
            this.btn_sair.TabIndex = 6;
            this.btn_sair.Text = "Sair";
            this.btn_sair.UseVisualStyleBackColor = true;
            this.btn_sair.Click += new System.EventHandler(this.btn_sair_Click);
            // 
            // lbl_resultado
            // 
            this.lbl_resultado.AutoSize = true;
            this.lbl_resultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lbl_resultado.Location = new System.Drawing.Point(18, 187);
            this.lbl_resultado.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_resultado.Name = "lbl_resultado";
            this.lbl_resultado.Size = new System.Drawing.Size(116, 26);
            this.lbl_resultado.TabIndex = 6;
            this.lbl_resultado.Text = "Resultado:";
            // 
            // txt_A
            // 
            this.txt_A.Location = new System.Drawing.Point(140, 27);
            this.txt_A.Margin = new System.Windows.Forms.Padding(2);
            this.txt_A.Name = "txt_A";
            this.txt_A.Size = new System.Drawing.Size(149, 20);
            this.txt_A.TabIndex = 1;
            this.txt_A.Validated += new System.EventHandler(this.txt_A_Validated);
            // 
            // txt_B
            // 
            this.txt_B.Location = new System.Drawing.Point(139, 76);
            this.txt_B.Margin = new System.Windows.Forms.Padding(2);
            this.txt_B.Name = "txt_B";
            this.txt_B.Size = new System.Drawing.Size(149, 20);
            this.txt_B.TabIndex = 2;
            this.txt_B.Validated += new System.EventHandler(this.txt_B_Validated);
            // 
            // txt_C
            // 
            this.txt_C.Location = new System.Drawing.Point(140, 131);
            this.txt_C.Margin = new System.Windows.Forms.Padding(2);
            this.txt_C.Name = "txt_C";
            this.txt_C.Size = new System.Drawing.Size(149, 20);
            this.txt_C.TabIndex = 3;
            this.txt_C.Validated += new System.EventHandler(this.txt_C_Validated);
            // 
            // txt_resultado
            // 
            this.txt_resultado.Location = new System.Drawing.Point(140, 193);
            this.txt_resultado.Margin = new System.Windows.Forms.Padding(2);
            this.txt_resultado.Name = "txt_resultado";
            this.txt_resultado.ReadOnly = true;
            this.txt_resultado.Size = new System.Drawing.Size(149, 20);
            this.txt_resultado.TabIndex = 0;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // txt_Triangulo
            // 
            this.txt_Triangulo.Location = new System.Drawing.Point(443, 193);
            this.txt_Triangulo.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Triangulo.Name = "txt_Triangulo";
            this.txt_Triangulo.ReadOnly = true;
            this.txt_Triangulo.Size = new System.Drawing.Size(149, 20);
            this.txt_Triangulo.TabIndex = 0;
            // 
            // lbl_Triangulo
            // 
            this.lbl_Triangulo.AutoSize = true;
            this.lbl_Triangulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lbl_Triangulo.Location = new System.Drawing.Point(323, 187);
            this.lbl_Triangulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Triangulo.Name = "lbl_Triangulo";
            this.lbl_Triangulo.Size = new System.Drawing.Size(122, 26);
            this.lbl_Triangulo.TabIndex = 13;
            this.lbl_Triangulo.Text = "É triangulo:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Ptrinangulo.Properties.Resources.triangulos_foto1;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(327, 27);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(263, 138);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 292);
            this.Controls.Add(this.lbl_Triangulo);
            this.Controls.Add(this.txt_Triangulo);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txt_resultado);
            this.Controls.Add(this.txt_C);
            this.Controls.Add(this.txt_B);
            this.Controls.Add(this.txt_A);
            this.Controls.Add(this.lbl_resultado);
            this.Controls.Add(this.btn_sair);
            this.Controls.Add(this.btn_limpar);
            this.Controls.Add(this.btn_calcular);
            this.Controls.Add(this.lbl_C);
            this.Controls.Add(this.lbl_B);
            this.Controls.Add(this.lbl_A);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Identificador de Triângulos";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_A;
        private System.Windows.Forms.Label lbl_B;
        private System.Windows.Forms.Label lbl_C;
        private System.Windows.Forms.Button btn_calcular;
        private System.Windows.Forms.Button btn_limpar;
        private System.Windows.Forms.Button btn_sair;
        private System.Windows.Forms.Label lbl_resultado;
        private System.Windows.Forms.TextBox txt_A;
        private System.Windows.Forms.TextBox txt_B;
        private System.Windows.Forms.TextBox txt_C;
        private System.Windows.Forms.TextBox txt_resultado;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label lbl_Triangulo;
        private System.Windows.Forms.TextBox txt_Triangulo;
    }
}

