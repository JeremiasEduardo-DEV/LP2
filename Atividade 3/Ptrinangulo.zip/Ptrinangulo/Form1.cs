﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptrinangulo
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;

        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_sair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txt_B_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txt_B, "");

                valorB = Convert.ToDouble(txt_B.Text);
            }
            catch
            {
                errorProvider1.SetError(txt_B, "Valor B inválido!");
                txt_B.Focus();
            }
        }

        private void txt_C_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txt_C, "");

                valorC = Convert.ToDouble(txt_C.Text);
            }
            catch
            {
                errorProvider1.SetError(txt_C, "Valor C inválido!");
                txt_C.Focus();
            }
        }

        private void btn_calcular_Click(object sender, EventArgs e)
        {
            //OBS: depois de uma pesquisa conclui que usar os valores 1, 2 e 3 não resulta num triangulo, pois 1 + 2 = 3 e um dos lado é 3, matematicamente falando é impossivel ser um triangulo.
            if ((valorA < valorB + valorC) && (valorB < valorA + valorC) && (valorC < valorA + valorB))
            {
                txt_Triangulo.Text = "É um triangulo";

                if (valorA == valorB && valorA == valorC)
                {
                    txt_resultado.Text = "É um triangulo equilatero";
                }
                else if (valorA == valorB || valorB == valorC || valorC == valorA)
                {
                    txt_resultado.Text = "É um triangulo isósceles";
                }
                else
                {
                    txt_resultado.Text = "É um triangulo escaleno";
                }
            }
            else
            {

                txt_Triangulo.Text = "Valores inválidos";
                txt_resultado.Text = "As medidas informadas não formam um triângulo.";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_limpar_Click(object sender, EventArgs e)
        {
            //limpar os dados
            txt_A.Clear();
            txt_B.Clear();
            txt_C.Clear();
            txt_resultado.Clear();
            txt_Triangulo.Clear();

            valorA = 0;
            valorB = 0;
            valorC = 0;

            txt_A.Focus();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txt_A_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txt_A, "");

                valorA = Convert.ToDouble(txt_A.Text);
            }
            catch
            {
                errorProvider1.SetError(txt_A, "Valor A inválido!");
                txt_A.Focus();
            }
        }
    }
}
