﻿namespace PConsumo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbx_consumo = new System.Windows.Forms.ListBox();
            this.btn_InserirVal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbx_consumo
            // 
            this.lbx_consumo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbx_consumo.FormattingEnabled = true;
            this.lbx_consumo.ItemHeight = 17;
            this.lbx_consumo.Location = new System.Drawing.Point(426, 17);
            this.lbx_consumo.Name = "lbx_consumo";
            this.lbx_consumo.Size = new System.Drawing.Size(310, 412);
            this.lbx_consumo.TabIndex = 0;
            // 
            // btn_InserirVal
            // 
            this.btn_InserirVal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btn_InserirVal.Location = new System.Drawing.Point(96, 186);
            this.btn_InserirVal.Name = "btn_InserirVal";
            this.btn_InserirVal.Size = new System.Drawing.Size(212, 100);
            this.btn_InserirVal.TabIndex = 1;
            this.btn_InserirVal.Text = "Inserir valores";
            this.btn_InserirVal.UseVisualStyleBackColor = true;
            this.btn_InserirVal.Click += new System.EventHandler(this.btn_InserirVal_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(777, 450);
            this.Controls.Add(this.btn_InserirVal);
            this.Controls.Add(this.lbx_consumo);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lbx_consumo;
        private System.Windows.Forms.Button btn_InserirVal;
    }
}

