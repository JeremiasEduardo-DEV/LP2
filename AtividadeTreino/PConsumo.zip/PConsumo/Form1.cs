﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PConsumo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_InserirVal_Click(object sender, EventArgs e)
        {
            string[] setores = { "Produção", "Escritório", "Refeitório", "Limpeza", "Logística" };
    
            double[,] Consumo = new double[5, 4];

           
                lbx_consumo.Items.Clear();

                double totalGeralLitros = 0;

                for (int i = 0; i < Consumo.GetLength(0); i++)
                {
                    double totalSetorLitros = 0;

                    for (int j = 0; j < Consumo.GetLength(1); j++)
                    {
               
                        string input = Interaction.InputBox(
                            $"Digite o consumo em litros para o setor {setores[i]} na Semana {j + 1}:",
                            "Entrada de Consumo",
                            "0"
                        );

           
                        double.TryParse(input, out double valor);

                      
                        Consumo[i, j] = valor;
                        totalSetorLitros += valor;
                    }

                    
                    double custoSetorReais = totalSetorLitros * 0.01;
                    totalGeralLitros += totalSetorLitros;

                   
                    lbx_consumo.Items.Add($"{setores[i]}: {totalSetorLitros.ToString("N0")} L -> {custoSetorReais.ToString("C2")}");
                }

              
               double custoTotalGeralReais = totalGeralLitros * 0.01;

                lbx_consumo.Items.Add("--------------------------------------------------");
                lbx_consumo.Items.Add($"Total Geral: {totalGeralLitros.ToString("N0")} L -> {custoTotalGeralReais.ToString("C2")}");
            
        }
    }
}
